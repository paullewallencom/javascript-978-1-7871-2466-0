//Run this only on BabelJS REPL - https://babeljs.io/repl/
if(true){
     const a=1;
     console.log(a);
     a=100;  ///"a" is read-only, you will get a TypeError
}