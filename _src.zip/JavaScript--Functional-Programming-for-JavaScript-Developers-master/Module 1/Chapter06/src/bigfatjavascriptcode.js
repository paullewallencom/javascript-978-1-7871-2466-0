function capitalizeName(name){
  if(name){
    return name.toUpperCase();
  }
}
