module Westeros{
  export class Ruler{
    house = new Westeros.Houses.Targaryen();
  }
}

module Westeros.Houses{
  export class Targaryen{}
}
