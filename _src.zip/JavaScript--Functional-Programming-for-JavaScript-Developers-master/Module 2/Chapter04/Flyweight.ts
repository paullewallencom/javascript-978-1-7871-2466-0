module Westeros.Army
{
  export class Soldier{
    public Health:number = 10;
    public FightingAbility: number = 5;
    public Hunger: number = 0;
  }

}
